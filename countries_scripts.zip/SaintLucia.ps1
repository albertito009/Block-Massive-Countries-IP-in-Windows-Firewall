# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_SaintLucia  `
dir=in action=block `
remoteip= `
`
24.92.144.0/20,66.212.62.0/23,72.14.98.0/23,104.218.216.0/22,104.255.252.0/22,162.0.155.0/24,162.212.208.0/23,162.245.76.0/22,192.58.142.0/23,192.147.231.0/24,199.38.192.0/21,199.192.226.0/23,199.223.248.0/22,204.145.147.0/24,204.152.80.0/23,205.166.35.0/24,206.126.120.0/21,207.191.248.0/21,208.94.176.0/21