# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Bermudas   `
dir=in action=block `
remoteip= `
`
45.42.144.0/22,64.37.32.0/20,64.147.80.0/20,66.55.112.0/20,66.97.172.0/23,69.17.192.0/19,74.114.240.0/22,76.8.32.0/20,104.218.168.0/21,142.54.192.0/21,162.219.233.0/24,162.221.212.0/22,162.255.216.0/21,192.40.84.0/22,192.156.199.0/24,192.219.29.0/24,196.1.107.0/24,196.12.64.0/18,198.182.170.0/24,198.186.235.0/24,198.187.171.0/24,198.207.16.0/21,199.15.228.0/22,199.16.248.0/22,199.27.70.0/23,199.68.192.0/22,199.87.170.0/23,199.96.64.0/22,199.193.228.0/22,200.1.160.0/24,200.10.165.0/24,200.10.166.0/24,204.13.24.0/21,205.211.8.0/23,206.53.176.0/20,206.188.128.0/19,207.2.96.0/21,207.228.128.0/18,208.64.0.0/23,208.64.6.0/23,208.75.200.0/22,208.82.164.0/22,208.89.228.0/22,209.240.32.0/20,216.249.32.0/20,31.47.88.0/21,83.229.103.0/24,83.229.108.0/24,83.229.111.0/24,185.198.104.0/22