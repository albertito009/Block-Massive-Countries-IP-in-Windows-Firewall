# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Gabon  `
dir=in action=block `
remoteip= `
`
41.78.240.0/22,41.158.0.0/15,41.211.128.0/18,102.129.32.0/22,102.134.28.0/22,102.135.164.0/22,102.142.0.0/16,102.164.124.0/22,154.0.32.0/19,154.0.176.0/20,154.112.0.0/16,154.116.0.0/17,154.119.192.0/19,160.119.160.0/19,169.159.0.0/18,169.239.148.0/22,169.255.148.0/22,192.188.164.0/22,192.189.139.0/24,192.189.140.0/24,196.49.17.0/24,196.50.32.0/23,196.223.39.0/24,197.231.64.0/18,197.242.0.0/19,217.77.64.0/20