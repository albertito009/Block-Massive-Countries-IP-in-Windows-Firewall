# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Cuba  `
dir=in action=block `
remoteip= `
`
152.206.0.0/15,169.158.0.0/16,181.225.224.0/19,190.6.64.0/20,190.6.80.0/20,190.15.144.0/20,190.92.112.0/20,190.107.0.0/20,196.1.112.0/24,196.1.135.0/24,196.3.152.0/24,200.0.16.0/24,200.0.24.0/22,200.5.12.0/22,200.13.144.0/21,200.14.48.0/21,200.55.128.0/19,200.55.160.0/20,200.55.176.0/20,201.220.192.0/20,201.220.208.0/20