# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Reunion  `
dir=in action=block `
remoteip= `
`
41.213.128.0/17,41.242.124.0/22,62.61.192.0/18,102.35.0.0/16,102.135.224.0/20,102.213.8.0/22,102.215.220.0/23,129.122.64.0/18,139.26.0.0/16,154.67.0.0/17,154.67.128.0/17,164.160.68.0/22,164.160.224.0/20,165.90.128.0/18,165.169.0.0/16,168.253.128.0/18,5.57.96.0/19,78.108.224.0/20,80.69.208.0/20,109.122.128.0/18,185.147.224.0/22,185.161.8.0/22,185.165.32.0/22,213.55.0.0/18,193.56.203.0/24