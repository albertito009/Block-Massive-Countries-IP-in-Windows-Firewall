# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Tonga      `
dir=in action=block `
remoteip= `
`
43.255.148.0/22,103.54.78.0/23,103.124.187.0/24,103.134.118.0/23,103.154.96.0/23,103.239.160.0/22,103.242.126.0/23,103.245.160.0/22,175.176.144.0/21,202.43.8.0/21,202.134.24.0/21