# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Guam  `
dir=in action=block `
remoteip= `
`
43.240.88.0/22,43.247.60.0/22,49.128.104.0/22,101.99.128.0/17,103.3.240.0/22,103.7.100.0/22,103.17.112.0/22,103.115.192.0/23,103.142.152.0/23,103.212.24.0/22,114.142.192.0/19,114.142.224.0/19,116.68.0.0/20,116.68.16.0/20,117.20.120.0/21,121.55.192.0/18,139.5.136.0/22,182.173.192.0/18,202.22.176.0/20,202.47.144.0/20,202.123.128.0/19,202.128.0.0/19,202.128.64.0/19,202.131.160.0/19,202.151.64.0/19,203.95.8.0/21,203.215.52.0/22,168.123.0.0/16,192.149.202.0/24