# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Tunisia      `
dir=in action=block `
remoteip= `
`
41.62.0.0/16,41.224.0.0/13,102.24.0.0/13,102.104.0.0/13,102.128.0.0/18,102.141.204.0/22,102.152.0.0/14,102.156.0.0/14,102.164.112.0/23,102.168.0.0/13,102.210.140.0/22,102.211.208.0/22,102.212.8.0/23,102.215.218.0/23,102.217.168.0/22,102.217.210.0/24,102.219.112.0/22,102.219.164.0/22,102.219.176.0/22,102.220.118.0/24,102.221.128.0/22,102.240.0.0/14,154.72.224.0/20,154.104.0.0/13,160.156.0.0/14,164.160.0.0/22,165.50.0.0/15,169.255.68.0/22,192.68.138.0/24,193.95.0.0/17,196.41.95.0/24,196.176.0.0/14,196.184.0.0/14,196.203.0.0/16,196.216.156.0/22,196.224.0.0/12,197.0.0.0/11,197.238.0.0/16,197.240.0.0/16,197.244.0.0/16,213.150.160.0/19,91.198.207.0/24,193.39.113.0/24,193.105.15.0/24,193.218.123.0/24