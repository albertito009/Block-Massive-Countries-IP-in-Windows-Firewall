# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Nicaragua  `
dir=in action=block `
remoteip= `
`
45.5.216.0/22,45.170.224.0/22,45.182.142.0/24,45.238.28.0/22,131.255.16.0/24,138.97.160.0/22,138.117.4.0/22,138.185.28.0/22,138.185.104.0/22,143.137.24.0/22,143.202.252.0/22,152.231.32.0/20,161.0.32.0/19,165.98.0.0/16,170.80.16.0/22,170.84.132.0/22,170.246.152.0/22,186.1.0.0/18,186.76.0.0/15,190.106.0.0/19,190.106.48.0/20,190.107.208.0/22,190.124.32.0/21,190.143.240.0/20,190.181.128.0/18,190.184.0.0/18,190.184.64.0/18,190.212.0.0/18,190.212.64.0/18,190.212.128.0/17,191.98.224.0/21,191.98.232.0/22,191.98.236.0/23,191.98.238.0/24,191.98.240.0/20,191.102.48.0/21,191.103.112.0/20,192.107.104.0/24,192.136.42.0/23,192.136.44.0/22,200.1.152.0/24,200.6.55.0/24,200.9.187.0/24,200.9.188.0/22,200.9.192.0/24,200.10.205.0/24,200.11.30.0/24,200.62.64.0/19,200.62.96.0/19,200.85.160.0/20,200.106.247.0/24,201.131.66.0/24,201.131.115.0/24,207.248.86.0/24