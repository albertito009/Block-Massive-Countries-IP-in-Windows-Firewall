# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Samoa  `
dir=in action=block `
remoteip= `
`
43.241.164.0/22,103.9.228.0/22,103.55.178.0/24,103.63.27.0/24,103.131.62.0/23,103.143.149.0/24,103.154.194.0/23,110.5.112.0/22,123.176.72.0/21,182.50.72.0/22,182.50.168.0/22,202.4.32.0/19,202.87.208.0/22,203.99.156.0/22,203.99.255.0/24