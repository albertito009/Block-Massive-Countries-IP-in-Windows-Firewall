# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Burundi  `
dir=in action=block `
remoteip= `
`
41.79.44.0/22,41.79.224.0/22,102.134.96.0/20,154.73.40.0/22,154.73.104.0/22,154.117.192.0/18,154.119.0.0/19,196.2.8.0/21,196.13.223.0/24,196.49.3.0/24,196.223.3.0/24,196.223.36.0/24,197.157.192.0/22