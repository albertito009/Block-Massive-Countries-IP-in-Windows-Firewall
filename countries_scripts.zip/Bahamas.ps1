# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Bahamas      `
dir=in action=block `
remoteip= `
`
23.185.48.0/24,23.190.112.0/24,24.51.64.0/18,24.206.0.0/19,24.231.32.0/19,24.244.128.0/18,64.66.0.0/20,64.150.192.0/18,65.75.64.0/18,66.85.2.0/24,66.226.160.0/19,69.4.160.0/20,104.166.32.0/20,108.60.224.0/19,141.193.84.0/22,161.199.175.0/24,165.140.144.0/22,170.117.211.0/24,192.231.36.0/24,199.102.188.0/22,204.236.64.0/18,208.87.32.0/21,209.126.78.0/24,216.137.0.0/20,216.181.104.0/23