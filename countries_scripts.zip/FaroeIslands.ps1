# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_FaroeIslands  `
dir=in action=block `
remoteip= `
`
46.227.112.0/21,80.77.128.0/20,81.18.224.0/20,81.25.176.0/20,88.85.32.0/19,178.19.192.0/20,185.74.208.0/22,185.88.228.0/22,185.171.172.0/22,193.34.104.0/22,195.80.36.0/22,212.55.32.0/19,217.172.80.0/20,198.137.136.0/22