# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Rwanda  `
dir=in action=block `
remoteip= `
`
41.74.160.0/20,41.138.80.0/21,41.186.0.0/16,41.197.0.0/16,41.222.244.0/22,41.242.140.0/22,102.22.128.0/18,102.130.32.0/21,102.209.168.0/22,102.211.72.0/22,102.213.212.0/23,102.214.220.0/23,102.215.8.0/22,102.218.176.0/22,102.219.173.0/24,105.178.0.0/17,105.179.0.0/19,154.68.64.0/18,156.38.8.0/21,196.44.240.0/20,196.49.7.0/24,196.223.12.0/24,196.223.240.0/21,197.157.128.0/18,197.157.212.0/22,197.234.244.0/22,197.243.0.0/17