# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Senegal  `
dir=in action=block `
remoteip= `
`
41.82.0.0/15,41.208.128.0/18,41.214.0.0/17,41.219.0.0/18,102.36.136.0/22,102.36.147.0/24,102.164.128.0/18,102.209.164.0/22,102.209.208.0/22,102.214.191.0/24,154.65.32.0/21,154.73.172.0/22,154.115.128.0/20,154.124.0.0/15,160.0.128.0/18,169.239.136.0/22,196.1.92.0/24,196.1.93.0/24,196.1.94.0/24,196.1.95.0/24,196.1.96.0/24,196.1.97.0/24,196.1.98.0/24,196.1.99.0/24,196.1.100.0/24,196.49.42.0/24,196.50.8.0/21,196.60.40.0/24,196.207.192.0/18,196.216.188.0/22,196.223.252.0/24,196.250.200.0/22,213.154.64.0/19