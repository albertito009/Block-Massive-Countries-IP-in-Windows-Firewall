# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Guinea  `
dir=in action=block `
remoteip= `
`
41.77.184.0/21,41.79.200.0/22,41.79.236.0/22,41.191.220.0/22,41.223.48.0/22,41.242.88.0/22,45.220.52.0/22,102.176.160.0/20,102.209.204.0/22,102.211.199.0/24,102.218.129.0/24,102.218.136.0/22,102.218.236.0/22,160.119.128.0/21,196.41.90.0/24,196.49.40.0/24,196.49.64.0/24,196.60.38.0/24,196.60.61.0/24,197.149.192.0/18