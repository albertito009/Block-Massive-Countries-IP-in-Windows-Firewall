# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Algeria      `
dir=in action=block `
remoteip= `
`
41.96.0.0/12,41.200.0.0/15,41.220.144.0/20,41.221.16.0/20,41.223.236.0/22,80.88.12.0/22,80.246.0.0/20,80.249.64.0/20,102.213.56.0/22,102.218.188.0/22,102.220.28.0/22,105.96.0.0/12,105.235.128.0/20,129.45.0.0/17,154.73.92.0/22,154.121.0.0/16,154.240.0.0/12,168.253.96.0/20,192.52.232.0/24,192.245.148.0/24,193.41.146.0/23,193.194.64.0/19,195.24.80.0/21,195.39.218.0/23,196.20.64.0/18,196.29.40.0/22,196.41.224.0/19,197.112.0.0/13,197.140.0.0/14,197.200.0.0/13,213.179.160.0/19