# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Barbados   `
dir=in action=block `
remoteip= `
`
23.236.0.0/20,64.119.192.0/20,65.48.128.0/17,69.73.192.0/18,69.80.0.0/18,72.22.128.0/19,72.51.64.0/18,104.153.128.0/21,104.200.96.0/20,104.218.176.0/22,162.212.12.0/22,162.220.136.0/21,162.246.104.0/21,192.65.160.0/21,192.171.120.0/21,192.214.112.0/20,192.235.48.0/20,196.1.160.0/20,196.3.192.0/19,198.56.56.0/21,198.245.160.0/24,198.246.229.0/24,198.246.230.0/24,199.7.112.0/21,199.47.52.0/22,199.58.152.0/22,199.254.104.0/21,200.50.64.0/19,205.214.192.0/19,216.110.96.0/19