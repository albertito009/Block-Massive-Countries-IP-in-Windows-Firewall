# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Jersey  `
dir=in action=block `
remoteip= `
`
165.250.0.0/16,5.35.160.0/21,5.42.128.0/21,31.186.112.0/21,37.156.38.0/23,46.254.248.0/21,81.20.176.0/20,82.112.128.0/19,83.137.248.0/21,87.237.128.0/21,87.244.64.0/18,93.191.200.0/22,93.191.204.0/23,93.191.206.0/23,109.68.192.0/22,146.19.127.0/24,173.255.144.0/21,185.3.52.0/22,185.16.68.0/22,185.48.60.0/22,185.57.212.0/22,185.87.8.0/22,185.113.12.0/22,185.122.244.0/22,185.158.120.0/22,185.179.89.0/24,185.179.101.0/24,185.206.12.0/22,185.235.244.0/24,188.116.44.0/24,193.3.239.0/24,193.17.36.0/22,194.34.106.0/23,199.34.116.0/22,199.66.128.0/22,209.251.252.0/23,212.9.0.0/19,213.133.192.0/19,213.134.23.0/24,217.198.188.0/24,193.36.44.0/24,193.201.42.0/24