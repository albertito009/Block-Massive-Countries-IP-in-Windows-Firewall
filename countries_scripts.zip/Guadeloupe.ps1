# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Guadeloupe  `
dir=in action=block `
remoteip= `
`
104.250.0.0/19,107.191.208.0/20,137.83.76.0/24,137.83.102.0/24,142.202.112.0/22,192.149.44.0/22,199.91.160.0/22,207.90.254.0/23,208.72.228.0/22,208.79.96.0/22,208.94.168.0/22,208.103.148.0/23,209.35.0.0/22,216.230.17.0/24,216.230.19.0/24,5.187.96.0/19,46.238.128.0/18,93.121.128.0/17,95.138.0.0/17,185.29.48.0/22,213.16.0.0/19,213.188.160.0/19,193.218.114.0/24