# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_NoBodyKnows  `
dir=in action=block `
remoteip= `
`
36.50.36.0/24,36.50.50.0/24,103.165.99.0/24,103.165.99.0/24,103.165.99.0/24,103.165.99.0/24,103.165.99.0/24,103.165.99.0/24,103.165.99.0/24,103.165.99.0/24,103.165.99.0/24,103.11.244.0/24,103.11.244.0/24,103.11.244.0/24,103.11.244.0/24,103.11.244.0/24,103.11.244.0/24,203.11.96.0/24