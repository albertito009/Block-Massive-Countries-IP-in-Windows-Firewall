# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Malawi  `
dir=in action=block `
remoteip= `
`
41.70.0.0/17,41.75.112.0/20,41.77.8.0/21,41.78.56.0/22,41.78.216.0/22,41.78.248.0/22,41.79.88.0/22,41.87.0.0/19,41.190.92.0/22,41.216.228.0/22,41.217.216.0/22,41.221.96.0/20,41.222.184.0/21,45.221.25.0/24,102.36.145.0/24,102.70.0.0/15,102.130.101.0/24,102.176.250.0/24,102.209.16.0/23,102.209.60.0/22,102.211.20.0/23,102.211.23.0/24,102.213.28.0/22,102.213.177.0/24,102.218.160.0/22,102.219.182.0/23,102.220.250.0/24,102.223.95.0/24,105.234.0.0/16,129.140.0.0/16,137.64.0.0/16,137.115.0.0/16,137.196.0.0/16,154.66.120.0/21,168.253.224.0/19,169.255.52.0/22,192.145.160.0/22,196.11.80.0/21,196.32.208.0/21,196.45.188.0/22,196.49.72.0/24,196.60.122.0/24,196.216.8.0/21,196.223.27.0/24,197.211.96.0/19