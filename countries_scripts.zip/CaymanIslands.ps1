# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_CaymanIslands  `
dir=in action=block `
remoteip= `
`
23.188.0.0/24,63.136.112.0/21,74.117.216.0/21,74.222.64.0/19,76.76.15.0/24,138.43.115.0/24,138.43.248.0/22,149.112.19.0/24,161.199.132.0/22,162.211.136.0/22,162.247.220.0/22,162.249.128.0/21,173.225.208.0/20,192.0.4.0/22,192.160.250.0/24,199.201.84.0/22,208.82.216.0/22,208.157.144.0/21,208.168.224.0/19,209.27.52.0/22,209.27.60.0/22,216.144.80.0/20,157.207.32.0/22