# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_NewCalzedonia  `
dir=in action=block `
remoteip= `
`
27.122.0.0/22,43.224.192.0/22,43.245.212.0/22,43.255.236.0/22,45.114.232.0/23,61.5.208.0/20,101.101.0.0/18,103.2.184.0/22,103.17.44.0/22,103.23.52.0/22,103.24.112.0/22,103.29.152.0/22,103.43.156.0/22,103.105.191.0/24,103.123.232.0/23,103.152.32.0/24,103.173.58.0/23,113.20.32.0/20,113.20.48.0/20,113.21.96.0/20,113.21.112.0/20,114.69.176.0/20,114.69.192.0/20,114.69.208.0/20,115.126.160.0/20,115.126.176.0/20,118.179.224.0/19,163.47.224.0/22,163.47.248.0/22,175.158.128.0/18,180.214.96.0/19,202.0.156.0/22,202.22.128.0/19,202.22.224.0/20,202.87.128.0/19,202.166.176.0/21,202.171.64.0/20,203.20.74.0/23,203.34.36.0/24,203.80.48.0/21,203.104.48.0/20,203.147.64.0/20,203.147.80.0/21,220.156.160.0/20,223.29.128.0/19,223.29.160.0/20