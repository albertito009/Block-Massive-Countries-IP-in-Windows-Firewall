# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Curasao  `
dir=in action=block `
remoteip= `
`
45.71.156.0/22,45.234.112.0/22,131.72.112.0/22,131.221.144.0/22,138.99.212.0/22,138.219.140.0/22,161.0.96.0/20,161.22.48.0/21,170.245.0.0/22,177.93.140.0/23,186.2.176.0/20,186.148.216.0/21,186.190.232.0/22,186.190.240.0/20,190.2.128.0/19,190.2.160.0/19,190.4.128.0/19,190.4.160.0/19,190.13.120.0/21,190.88.0.0/18,190.88.64.0/18,190.88.128.0/17,190.105.192.0/22,190.112.224.0/20,190.112.240.0/20,190.121.208.0/20,190.121.240.0/20,190.123.20.0/22,190.185.0.0/18,196.3.16.0/20,200.0.20.0/23,200.6.56.0/21,200.16.93.0/24,200.26.192.0/20,200.26.208.0/20,200.61.253.0/24,200.115.179.0/24,200.124.128.0/20,200.124.144.0/20,201.131.43.0/24,216.152.160.0/20,45.8.104.0/22,81.29.0.0/20,185.149.84.0/22,185.185.184.0/22,193.23.16.0/22,217.78.240.0/20,91.194.236.0/23