# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Mauritania  `
dir=in action=block `
remoteip= `
`
41.138.128.0/19,41.188.64.0/18,41.223.96.0/22,82.151.64.0/19,102.214.128.0/22,102.214.208.0/22,102.215.95.0/24,102.216.27.0/24,102.216.216.0/22,102.219.207.0/24,196.49.18.0/24,196.223.45.0/24,197.231.0.0/19