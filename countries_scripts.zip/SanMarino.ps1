# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_SanMarino  `
dir=in action=block `
remoteip= `
`
31.193.32.0/21,45.65.80.0/22,77.242.208.0/20,89.186.32.0/19,109.233.80.0/21,109.235.104.0/21,185.21.116.0/22,185.21.132.0/24,185.45.40.0/22,185.45.68.0/22,185.62.32.0/22,185.86.60.0/22,185.146.128.0/22,185.168.168.0/22,192.145.48.0/22,194.183.64.0/19,91.223.220.0/24,91.234.215.0/24,94.232.112.0/21,194.0.27.0/24