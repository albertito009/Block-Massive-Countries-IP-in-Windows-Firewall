# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Jamaica  `
dir=in action=block `
remoteip= `
`
23.156.32.0/24,63.143.64.0/18,64.112.16.0/22,65.183.0.0/20,66.54.112.0/20,66.212.52.0/22,66.249.144.0/20,67.213.144.0/20,69.160.96.0/19,72.27.0.0/17,72.27.128.0/18,72.27.192.0/19,74.116.56.0/22,96.43.160.0/19,104.152.236.0/22,104.244.224.0/21,142.0.224.0/20,162.216.160.0/21,162.246.0.0/22,170.62.168.0/22,170.62.196.0/22,173.225.240.0/20,184.170.0.0/18,192.131.32.0/21,196.1.136.0/24,196.1.138.0/23,196.2.0.0/24,196.2.1.0/24,196.3.0.0/21,196.3.95.0/24,196.3.104.0/24,196.3.153.0/24,196.3.184.0/21,196.32.0.0/21,198.58.0.0/23,199.73.60.0/22,199.115.28.0/23,199.195.220.0/22,200.9.115.0/24,200.10.152.0/24,206.41.107.0/24,207.204.64.0/18,207.254.128.0/20,208.131.160.0/19,208.138.16.0/20,208.138.32.0/20,208.163.32.0/19,209.236.0.0/18,216.10.208.0/20