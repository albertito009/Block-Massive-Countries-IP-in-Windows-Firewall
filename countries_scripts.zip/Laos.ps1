# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Laos  `
dir=in action=block `
remoteip= `
`
43.224.36.0/22,43.228.84.0/22,43.252.244.0/22,101.78.8.0/21,103.1.28.0/22,103.1.232.0/22,103.13.88.0/22,103.26.103.0/24,103.43.76.0/22,103.59.52.0/22,103.63.188.0/24,103.66.238.0/23,103.81.180.0/24,103.82.56.0/22,103.95.24.0/22,103.109.116.0/22,103.112.191.0/24,103.114.146.0/23,103.137.88.0/22,103.138.142.0/24,103.140.246.0/23,103.145.48.0/24,103.150.74.0/23,103.151.76.0/23,103.164.89.0/24,103.174.8.0/23,103.205.16.0/22,103.228.101.0/24,103.228.252.0/22,103.232.80.0/22,103.240.240.0/22,103.245.164.0/24,103.245.167.0/24,114.129.24.0/21,115.84.64.0/18,139.5.156.0/22,141.164.96.0/20,157.15.126.0/23,157.119.180.0/22,180.131.148.0/22,183.182.96.0/19,185.19.104.0/22,185.126.144.0/22,185.129.140.0/22,202.9.76.0/23,202.62.96.0/20,202.123.176.0/21,202.136.240.0/21,202.137.128.0/19,202.144.184.0/21,203.19.5.0/24,203.76.252.0/22,203.110.64.0/20