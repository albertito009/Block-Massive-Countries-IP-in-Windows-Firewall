# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Sudan  `
dir=in action=block `
remoteip= `
`
41.67.0.0/18,41.78.108.0/22,41.95.0.0/16,41.202.160.0/19,41.209.64.0/18,41.218.0.0/18,41.223.160.0/22,41.223.200.0/22,41.240.0.0/15,62.12.96.0/20,102.120.0.0/13,102.130.248.0/21,102.143.128.0/17,102.181.0.0/17,102.181.128.0/18,102.181.192.0/19,102.210.236.0/22,102.218.68.0/22,102.218.99.0/24,102.220.152.0/22,105.238.0.0/15,154.96.0.0/13,155.196.0.0/16,196.1.192.0/18,196.29.160.0/19,196.49.66.0/24,196.202.128.0/19,196.223.20.0/24,196.223.152.0/21,197.208.0.0/15,197.251.0.0/17,197.252.0.0/16,197.254.192.0/19,197.254.224.0/19,212.0.128.0/19