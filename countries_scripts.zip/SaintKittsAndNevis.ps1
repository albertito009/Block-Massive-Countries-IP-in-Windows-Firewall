# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_SaintKittsAndNevis  `
dir=in action=block `
remoteip= `
`
23.131.208.0/24,23.137.40.0/24,149.112.30.0/24,198.167.192.0/19,199.21.164.0/22,204.16.8.0/22,204.19.200.0/22,204.76.203.0/24,207.167.92.0/22,208.70.92.0/22,208.81.160.0/22,208.87.144.0/22,216.211.197.0/24