# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_CaboVerde  `
dir=in action=block `
remoteip= `
`
41.74.128.0/20,41.79.124.0/22,41.215.208.0/20,41.221.192.0/20,102.69.151.0/24,102.209.52.0/22,102.209.160.0/22,102.211.8.0/22,102.212.81.0/24,102.212.175.0/24,102.213.204.0/22,102.214.188.0/24,102.216.132.0/24,102.219.86.0/23,102.220.164.0/22,102.222.140.0/22,165.90.96.0/19,169.239.12.0/22,196.49.96.0/24,196.60.112.0/24,197.255.128.0/20,213.150.192.0/21