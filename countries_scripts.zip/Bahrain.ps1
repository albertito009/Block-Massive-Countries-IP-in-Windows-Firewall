# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Bahrain      `
dir=in action=block `
remoteip= `
`
31.217.249.0/24,37.131.0.0/17,45.11.72.0/22,46.42.64.0/18,46.184.128.0/17,46.235.208.0/21,62.209.0.0/19,77.69.128.0/17,77.83.88.0/22,77.92.160.0/19,78.110.64.0/20,79.171.240.0/21,80.88.240.0/20,80.95.208.0/20,80.241.144.0/20,81.22.16.0/20,82.194.32.0/19,83.136.56.0/21,84.255.128.0/18,85.158.128.0/21,87.236.48.0/21,87.236.136.0/21,87.237.192.0/21,87.252.96.0/21,87.252.104.0/23,87.252.126.0/23,88.201.0.0/17,89.31.192.0/21,89.148.0.0/18,91.189.188.0/22,93.188.192.0/21,94.76.0.0/18,94.79.192.0/18,95.84.64.0/18,109.63.0.0/17,109.161.128.0/17,176.118.176.0/22,178.132.32.0/20,185.3.120.0/22,185.7.8.0/22,185.33.176.0/22,185.34.228.0/22,185.36.88.0/22,185.49.160.0/22,185.143.124.0/22,185.156.236.0/22,185.165.176.0/22,185.236.132.0/22,188.116.192.0/18,188.137.128.0/17,193.25.204.0/24,193.188.96.0/19,217.17.224.0/20,217.17.240.0/20,193.188.12.0/23