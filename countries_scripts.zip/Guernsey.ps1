# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Guernsey  `
dir=in action=block `
remoteip= `
`
45.11.144.0/22,45.135.252.0/22,46.31.240.0/21,46.235.128.0/21,78.41.0.0/21,92.43.208.0/21,93.187.0.0/21,93.189.160.0/21,185.37.76.0/22,185.85.253.0/24,185.104.200.0/22,185.110.36.0/22,185.143.248.0/22,185.159.16.0/22,185.201.0.0/22,195.226.128.0/19,213.163.192.0/19,193.104.140.0/24,194.9.2.0/23,194.116.244.0/23,194.145.126.0/24