# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Zimbabwe      `
dir=in action=block `
remoteip= `
`
41.57.64.0/20,41.78.76.0/22,41.79.28.0/22,41.79.56.0/22,41.79.188.0/22,41.85.192.0/19,41.190.32.0/19,41.191.232.0/21,41.220.16.0/20,41.221.144.0/20,102.128.76.0/22,102.165.112.0/22,102.177.72.0/22,102.177.192.0/21,102.210.112.0/22,102.212.220.0/22,102.212.231.0/24,102.213.40.0/22,102.217.48.0/22,102.218.12.0/22,154.73.80.0/22,154.119.80.0/20,168.253.32.0/19,169.239.24.0/22,196.4.80.0/24,196.29.32.0/21,196.41.88.0/24,196.43.96.0/19,196.43.199.0/24,196.44.176.0/20,196.49.46.0/24,196.60.44.0/24,196.216.224.0/23,196.220.96.0/19,197.157.204.0/22,197.221.224.0/19