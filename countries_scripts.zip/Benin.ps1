# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Benin   `
dir=in action=block `
remoteip= `
`
41.74.0.0/20,41.79.216.0/22,41.85.160.0/19,41.86.224.0/19,41.138.88.0/22,41.191.84.0/22,41.216.32.0/19,41.222.192.0/22,41.223.248.0/22,45.221.224.0/19,81.91.224.0/20,102.38.128.0/19,102.209.80.0/22,102.214.143.0/24,102.214.247.0/24,102.215.88.0/22,102.215.93.0/24,102.215.124.0/22,102.215.136.0/22,102.222.216.0/22,137.255.0.0/16,154.65.28.0/22,154.66.128.0/20,154.127.32.0/20,156.0.212.0/22,160.119.144.0/22,164.160.140.0/22,196.49.8.0/24,196.192.16.0/20,196.223.40.0/24,196.251.152.0/22,197.234.216.0/21