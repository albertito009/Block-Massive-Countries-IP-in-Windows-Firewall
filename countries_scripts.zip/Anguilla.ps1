# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Anguilla      `
dir=in action=block `
remoteip= `
`
104.192.92.0/22,104.193.196.0/22,104.255.176.0/22,162.251.108.0/22,162.254.188.0/22,192.30.124.0/24,204.14.248.0/21,208.66.48.0/21,195.149.107.0/24