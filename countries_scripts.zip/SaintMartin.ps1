# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_SaintMartin  `
dir=in action=block `
remoteip= `
`
23.138.120.0/24,74.112.232.0/21,74.116.92.0/22,148.64.60.0/23,149.112.46.0/23,158.222.40.0/23,192.96.136.0/23,192.139.192.0/24,199.19.28.0/22,199.101.188.0/22,204.27.52.0/22,208.78.48.0/21,208.91.192.0/22