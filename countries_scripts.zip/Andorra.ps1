# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Andorra      `
dir=in action=block `
remoteip= `
`
46.172.224.0/19,46.175.156.0/22,80.80.84.0/22,80.80.92.0/22,85.94.160.0/19,89.150.2.0/23,89.150.4.0/22,89.150.8.0/21,91.187.64.0/19,94.125.138.0/23,94.125.140.0/23,109.111.96.0/19,185.4.52.0/22,185.33.0.0/22,185.87.36.0/22,185.87.40.0/22,185.87.44.0/22,185.132.200.0/22,185.194.56.0/22,185.247.24.0/22,188.241.26.0/23,194.158.64.0/19