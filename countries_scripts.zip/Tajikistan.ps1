# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Tajikistan  `
dir=in action=block `
remoteip= `
`
37.98.152.0/21,45.81.37.0/24,45.94.216.0/22,46.20.192.0/21,46.20.200.0/23,46.20.202.0/23,46.20.204.0/22,77.95.0.0/21,77.244.144.0/20,77.247.198.0/24,79.170.184.0/21,80.73.240.0/24,85.8.129.0/24,85.9.128.0/18,89.104.121.0/24,91.193.26.0/24,94.199.16.0/21,95.142.80.0/20,109.68.232.0/21,109.74.64.0/21,109.74.72.0/24,109.74.73.0/24,109.74.74.0/23,109.74.76.0/22,109.75.48.0/20,146.19.183.0/24,185.42.96.0/22,185.105.228.0/22,185.121.0.0/23,185.121.2.0/23,185.166.56.0/22,185.177.0.0/22,185.191.52.0/22,185.194.196.0/23,185.194.198.0/24,185.194.199.0/24,185.208.96.0/22,185.222.211.0/24,193.33.130.0/23,193.33.136.0/23,193.57.208.0/22,217.8.32.0/20,217.11.176.0/20,217.197.105.0/24,45.124.96.0/23,62.122.136.0/21,91.200.216.0/22,91.218.160.0/22,91.218.168.0/22,91.231.252.0/22,91.235.36.0/22,141.193.59.0/24,162.120.21.0/24,176.113.128.0/20,193.111.10.0/23,195.246.102.0/23