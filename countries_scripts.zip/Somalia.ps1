# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Somalia  `
dir=in action=block `
remoteip= `
`
41.78.72.0/22,41.79.196.0/22,41.223.108.0/22,102.38.48.0/22,102.68.16.0/22,102.68.144.0/21,102.128.128.0/21,102.141.196.0/22,102.210.242.0/24,102.214.168.0/22,102.218.10.0/23,102.218.56.0/22,102.218.98.0/24,102.220.40.0/22,102.223.188.0/22,154.72.24.0/22,154.72.48.0/22,154.73.24.0/22,154.73.44.0/22,154.73.124.0/22,154.115.192.0/18,154.118.240.0/22,192.145.168.0/21,196.11.62.0/24,196.49.58.0/24,196.60.54.0/24,197.157.244.0/22,197.220.64.0/19,197.231.200.0/22