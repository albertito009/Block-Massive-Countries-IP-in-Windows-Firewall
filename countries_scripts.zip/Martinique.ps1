# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Martinique  `
dir=in action=block `
remoteip= `
`
104.245.112.0/21,104.249.191.0/24,192.163.24.0/22,5.102.72.0/21,80.243.240.0/20,82.197.96.0/19,89.16.0.0/19,92.49.64.0/18,93.176.0.0/18,94.124.152.0/21,94.124.216.0/21,94.198.176.0/21,109.62.0.0/17,109.203.224.0/19,185.13.216.0/22,185.14.99.0/24,185.21.212.0/22,185.60.232.0/22,185.91.232.0/22,188.115.64.0/18,217.175.160.0/20,217.175.176.0/20