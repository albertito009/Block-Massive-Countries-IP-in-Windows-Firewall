# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Yemen      `
dir=in action=block `
remoteip= `
`
5.100.160.0/21,5.255.0.0/19,31.31.176.0/20,46.35.64.0/19,46.161.224.0/19,78.137.64.0/19,80.253.176.0/20,81.91.24.0/21,82.114.160.0/19,89.189.64.0/19,94.26.192.0/20,94.26.208.0/20,109.74.32.0/20,109.200.160.0/19,131.117.160.0/21,178.130.64.0/18,185.11.8.0/22,185.71.132.0/22,185.80.44.0/22,185.80.140.0/22,185.112.200.0/22,185.240.64.0/22,188.209.224.0/19,188.240.96.0/19,195.94.0.0/19,213.246.0.0/19,110.238.32.0/19,134.35.0.0/16,175.110.0.0/18,176.123.16.0/20