# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_FrenchPolynesia  `
dir=in action=block `
remoteip= `
`
43.249.176.0/22,50.21.80.0/20,64.140.144.0/20,103.4.72.0/22,103.46.216.0/22,103.129.120.0/22,103.166.70.0/23,103.254.224.0/22,103.254.232.0/22,113.197.68.0/22,114.141.112.0/21,123.50.64.0/18,148.66.64.0/18,192.171.104.0/21,202.3.224.0/19,202.90.64.0/19,203.185.160.0/20,203.185.176.0/21,218.100.77.0/24