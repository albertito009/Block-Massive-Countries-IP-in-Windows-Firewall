# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Dominica  `
dir=in action=block `
remoteip= `
`
23.186.240.0/24,66.118.36.0/22,69.12.108.0/22,104.153.248.0/22,104.245.204.0/22,162.213.168.0/22,162.253.100.0/22,192.243.48.0/20,198.101.28.0/22,199.127.196.0/22,206.53.141.0/24,216.162.201.0/24,45.9.148.0/22,193.169.160.0/23