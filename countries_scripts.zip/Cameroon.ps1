# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Cameroon  `
dir=in action=block `
remoteip= `
`
41.77.80.0/21,41.92.128.0/21,41.92.152.0/21,41.92.180.0/22,41.92.184.0/22,41.92.196.0/22,41.92.200.0/22,41.92.208.0/21,41.92.216.0/22,41.92.224.0/24,41.92.248.0/21,41.190.224.0/22,41.191.100.0/22,41.202.192.0/19,41.204.64.0/19,41.205.0.0/19,41.205.64.0/19,41.211.96.0/19,41.216.232.0/22,41.217.148.0/22,41.223.28.0/22,102.132.16.0/20,102.135.189.0/24,102.209.19.0/24,102.210.68.0/22,102.210.116.0/22,102.211.54.0/24,102.216.38.0/24,102.218.164.0/22,102.218.252.0/22,102.219.44.0/22,102.219.68.0/22,102.220.16.0/22,102.220.222.0/24,102.223.6.0/24,102.244.0.0/14,129.0.0.0/16,154.70.96.0/19,154.72.128.0/18,154.126.128.0/19,154.126.160.0/19,165.210.0.0/15,169.239.40.0/22,169.255.4.0/22,192.145.186.0/23,195.24.192.0/19,196.3.90.0/24,196.49.38.0/24,196.49.84.0/24,196.60.6.0/24,196.60.7.0/24,196.60.84.0/24,196.202.232.0/21,196.216.212.0/24,197.159.0.0/19