# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Montenegro  `
dir=in action=block `
remoteip= `
`
31.204.192.0/18,37.0.64.0/21,37.122.160.0/19,46.33.192.0/19,46.161.64.0/18,62.4.32.0/19,77.91.80.0/20,77.91.96.0/20,77.91.112.0/20,77.222.0.0/19,78.155.32.0/19,79.140.144.0/20,79.143.96.0/20,81.28.248.0/22,84.54.45.0/24,85.94.96.0/19,89.188.32.0/19,89.207.192.0/21,92.42.96.0/24,93.95.29.0/24,94.102.224.0/20,95.155.0.0/18,109.72.96.0/20,109.228.64.0/18,185.12.40.0/22,185.38.184.0/22,185.40.188.0/22,185.42.163.0/24,185.64.0.0/22,185.68.48.0/22,185.80.96.0/22,185.132.160.0/22,185.147.200.0/22,185.149.144.0/22,185.157.120.0/24,185.163.224.0/22,185.179.52.0/22,185.179.92.0/22,185.215.88.0/22,185.255.228.0/22,193.32.112.0/22,195.10.205.0/24,195.66.160.0/19,213.133.0.0/19,213.149.96.0/19,213.196.64.0/19,91.217.138.0/24,91.220.187.0/24,185.1.44.0/24,195.140.164.0/22,195.242.169.0/24