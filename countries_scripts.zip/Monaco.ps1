# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Monaco  `
dir=in action=block `
remoteip= `
`
37.44.224.0/22,80.94.96.0/20,82.113.0.0/19,87.238.104.0/21,87.254.224.0/19,88.209.64.0/18,91.213.192.0/24,176.114.96.0/20,185.47.116.0/22,185.162.120.0/22,185.193.108.0/22,185.243.3.0/24,185.250.4.0/22,188.191.136.0/21,193.34.228.0/23,193.35.2.0/23,195.78.0.0/19,213.133.72.0/21,91.199.109.0/24,176.121.52.0/22,195.20.192.0/23