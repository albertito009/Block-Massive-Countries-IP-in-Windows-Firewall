# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Guyana  `
dir=in action=block `
remoteip= `
`
138.94.248.0/22,168.232.144.0/22,179.51.205.0/24,181.41.64.0/18,181.177.216.0/22,181.199.224.0/19,190.80.0.0/18,190.80.64.0/18,190.93.36.0/22,190.105.156.0/22,190.108.196.0/22,190.108.200.0/21,190.108.208.0/21,190.124.220.0/22