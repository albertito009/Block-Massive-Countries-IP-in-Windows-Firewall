# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Haiti  `
dir=in action=block `
remoteip= `
`
148.102.128.0/17,161.0.128.0/19,168.197.100.0/22,170.80.248.0/22,170.83.192.0/22,170.239.12.0/22,179.51.206.0/24,186.1.192.0/20,186.190.0.0/17,190.102.64.0/19,190.105.172.0/22,190.115.128.0/18,190.120.192.0/20,190.120.208.0/20,190.196.192.0/20,200.0.18.0/24,200.2.128.0/20,200.2.144.0/20,200.4.160.0/20,200.4.176.0/20,200.113.192.0/19,200.113.224.0/19,200.115.182.0/23,201.131.77.0/24,201.150.104.0/22