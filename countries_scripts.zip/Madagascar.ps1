# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Madagascar  `
dir=in action=block `
remoteip= `
`
41.63.128.0/19,41.74.16.0/20,41.74.208.0/20,41.77.16.0/21,41.188.0.0/18,41.190.236.0/22,41.204.96.0/19,41.207.32.0/19,41.242.96.0/20,102.16.0.0/14,102.20.0.0/15,102.68.192.0/18,102.211.100.0/22,102.216.23.0/24,154.120.128.0/18,154.126.0.0/17,196.43.214.0/24,196.49.13.0/24,196.192.32.0/20,196.223.41.0/24,197.148.128.0/18,197.149.0.0/18,197.158.64.0/18,197.159.144.0/20,197.215.192.0/20