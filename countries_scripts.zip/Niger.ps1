# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Niger  `
dir=in action=block `
remoteip= `
`
41.78.116.0/22,41.138.32.0/19,41.203.128.0/19,102.213.60.0/22,102.213.244.0/22,102.214.4.0/22,102.215.84.0/22,102.217.96.0/22,102.220.24.0/22,154.66.220.0/22,154.127.80.0/20,197.214.0.0/18