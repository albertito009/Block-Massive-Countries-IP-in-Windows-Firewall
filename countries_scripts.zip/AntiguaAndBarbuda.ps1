# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_AntiguaAndBarbuda      `
dir=in action=block `
remoteip= `
`
23.132.144.0/24,23.176.240.0/24,69.50.64.0/20,69.57.224.0/19,76.76.160.0/19,149.112.100.0/24,162.210.156.0/22,162.222.84.0/22,162.252.188.0/22,170.39.108.0/22,192.64.120.0/22,199.16.56.0/22,199.48.204.0/22,199.189.112.0/22,204.16.112.0/22,205.217.224.0/19,206.83.13.0/24,206.214.0.0/19,208.83.80.0/21,209.59.64.0/18,216.48.96.0/22,46.19.184.0/21,77.239.224.0/19,91.108.0.0/18,91.212.88.0/24,92.62.48.0/20,94.124.176.0/21,94.229.96.0/20,95.140.80.0/20,95.161.0.0/17,95.161.128.0/21,95.161.136.0/22,95.161.240.0/20,109.239.128.0/20,149.154.160.0/20,178.18.224.0/20,185.51.60.0/22,185.182.12.0/22,188.65.64.0/21,212.232.64.0/20,213.21.0.0/19,213.21.48.0/20