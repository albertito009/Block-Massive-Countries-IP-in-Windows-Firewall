# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_TrinidadAndTobago      `
dir=in action=block `
remoteip= `
`
45.185.20.0/22,45.234.164.0/22,45.237.88.0/22,64.28.128.0/20,131.72.76.0/22,131.100.36.0/22,131.100.160.0/22,131.221.28.0/22,138.59.24.0/22,138.94.240.0/22,143.0.172.0/22,143.137.192.0/22,161.0.112.0/21,161.0.224.0/19,168.195.120.0/22,170.0.244.0/22,170.82.208.0/22,170.82.216.0/22,170.84.8.0/22,170.246.160.0/22,179.0.28.0/24,179.60.212.0/22,181.118.32.0/19,181.188.0.0/17,186.44.0.0/15,186.96.208.0/20,186.195.248.0/22,190.6.224.0/20,190.58.0.0/16,190.59.0.0/16,190.83.128.0/17,190.93.0.0/19,190.93.64.0/18,190.97.96.0/20,190.213.0.0/18,190.213.64.0/18,190.213.128.0/17,196.3.132.0/22,196.3.136.0/21,196.3.144.0/22,196.29.64.0/19,196.32.32.0/19,200.1.104.0/21,200.3.176.0/21,200.7.88.0/21,200.9.216.0/23,200.9.218.0/24,200.12.240.0/21,200.108.0.0/20,200.108.16.0/20,200.125.160.0/21,201.221.64.0/20,201.221.80.0/20,201.238.64.0/19,201.238.96.0/20,201.238.112.0/21,201.238.120.0/22,201.238.124.0/22,209.94.192.0/19