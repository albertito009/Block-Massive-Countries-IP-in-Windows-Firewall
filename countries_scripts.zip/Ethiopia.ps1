# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Ethiopia  `
dir=in action=block `
remoteip= `
`
102.211.105.0/24,102.212.10.0/24,102.212.68.0/22,102.213.68.0/22,102.218.0.0/22,102.218.48.0/22,164.160.184.0/22,196.49.98.0/24,196.60.116.0/24,196.188.0.0/14,197.156.64.0/18,213.55.64.0/18