# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_SintMaarten  `
dir=in action=block `
remoteip= `
`
131.161.84.0/22,168.0.84.0/22,168.197.108.0/22,170.0.16.0/22,190.102.0.0/20,190.102.16.0/20,190.124.216.0/22,190.185.64.0/20,190.185.80.0/20,200.0.22.0/23,200.7.32.0/20,200.7.48.0/20,201.220.0.0/20