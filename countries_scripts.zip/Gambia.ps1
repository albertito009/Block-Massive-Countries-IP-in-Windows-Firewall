# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Gambia  `
dir=in action=block `
remoteip= `
`
41.76.8.0/21,41.223.212.0/22,102.69.160.0/22,102.140.128.0/19,102.211.12.0/22,102.211.244.0/22,102.213.220.0/22,102.216.248.0/22,102.221.64.0/22,146.196.128.0/17,155.251.0.0/16,160.182.0.0/15,196.46.232.0/21,196.49.1.0/24,196.223.34.0/24,196.223.144.0/21,197.148.72.0/21,197.231.128.0/21,197.231.204.0/22,197.242.128.0/20,197.255.192.0/20,212.60.64.0/19