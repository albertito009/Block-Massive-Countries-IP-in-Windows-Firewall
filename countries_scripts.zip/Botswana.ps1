# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Botswana  `
dir=in action=block `
remoteip= `
`
41.74.48.0/20,41.75.0.0/20,41.76.240.0/21,41.77.88.0/21,41.79.32.0/22,41.79.136.0/22,41.87.160.0/19,41.138.72.0/21,41.190.244.0/22,41.191.64.0/22,41.191.216.0/22,41.216.208.0/21,41.223.72.0/22,41.223.140.0/22,41.223.192.0/22,83.143.24.0/21,102.134.84.0/22,102.134.160.0/20,102.141.112.0/21,102.165.128.0/19,102.210.158.0/24,102.210.252.0/24,102.211.140.0/22,102.214.126.0/24,102.215.0.0/22,102.219.75.0/24,102.219.206.0/24,102.222.8.0/22,102.222.48.0/22,102.222.173.0/24,105.235.240.0/20,129.205.192.0/18,154.0.16.0/21,154.70.144.0/21,154.73.36.0/22,154.73.84.0/22,156.38.4.0/22,156.38.16.0/20,168.167.0.0/16,169.255.80.0/22,196.2.2.0/24,196.45.164.0/22,196.49.24.0/24,196.60.4.0/24,196.61.208.0/21,196.216.163.0/24,197.231.192.0/22