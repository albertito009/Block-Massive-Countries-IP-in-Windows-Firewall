# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Lesotho  `
dir=in action=block `
remoteip= `
`
41.76.16.0/21,41.191.200.0/21,41.203.176.0/20,64.57.112.0/20,102.36.240.0/22,102.214.112.0/22,129.232.0.0/17,154.66.108.0/22,156.0.0.0/18,196.4.255.0/24,196.11.175.0/24,196.43.249.0/24,196.202.240.0/21,196.223.24.0/24,197.155.192.0/20,197.189.128.0/18,197.220.128.0/19,197.231.32.0/19,197.254.128.0/18