# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Aruba      `
dir=in action=block `
remoteip= `
`
138.255.252.0/22,170.84.254.0/24,179.61.32.0/19,181.41.0.0/18,186.96.200.0/21,186.96.224.0/20,186.96.240.0/21,186.189.0.0/18,186.189.128.0/18,190.12.224.0/19,190.104.96.0/20,201.229.0.0/18,201.229.64.0/18