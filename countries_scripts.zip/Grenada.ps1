# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Grenada  `
dir=in action=block `
remoteip= `
`
23.130.168.0/24,23.141.216.0/24,45.42.225.0/24,67.159.199.0/24,74.117.84.0/22,74.122.88.0/21,104.245.48.0/22,104.245.92.0/22,162.245.152.0/22,196.3.73.0/24,199.83.192.0/21,199.85.236.0/22,206.126.244.0/24