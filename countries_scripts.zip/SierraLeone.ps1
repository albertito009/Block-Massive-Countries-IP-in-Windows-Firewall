# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_SierraLeone  `
dir=in action=block `
remoteip= `
`
41.78.84.0/22,41.191.248.0/22,41.223.132.0/22,102.22.104.0/22,102.23.140.0/22,102.143.0.0/17,102.210.52.0/24,102.210.193.0/24,102.216.238.0/23,102.220.249.0/24,102.223.154.0/23,102.223.168.0/22,160.19.152.0/22,160.20.112.0/22,165.73.236.0/22,169.239.196.0/22,169.239.244.0/22,196.43.229.0/24,196.216.220.0/23,196.223.10.0/24,197.157.232.0/22,197.215.0.0/17