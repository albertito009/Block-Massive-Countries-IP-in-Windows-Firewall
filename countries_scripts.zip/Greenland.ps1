# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Greenland  `
dir=in action=block `
remoteip= `
`
37.18.44.0/22,37.230.164.0/22,37.230.214.0/23,37.230.216.0/22,37.230.220.0/23,46.16.16.0/21,46.243.151.0/24,88.83.0.0/19,128.0.70.0/24,178.170.132.0/22,178.170.147.0/24,178.170.160.0/22,178.170.199.0/24,178.170.200.0/22,178.170.204.0/23,178.170.210.0/23,178.170.212.0/22,178.170.216.0/24,185.18.188.0/22,185.21.228.0/22,185.57.160.0/22,185.93.20.0/22,185.157.200.0/22,188.72.71.0/24,194.177.224.0/19