# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_BurkinaFaso  `
dir=in action=block `
remoteip= `
`
41.78.48.0/22,41.78.52.0/22,41.138.96.0/19,41.203.224.0/20,41.216.144.0/20,41.223.232.0/22,102.23.0.0/18,102.36.164.0/22,102.67.96.0/19,102.67.172.0/22,102.68.32.0/21,102.68.100.0/22,102.68.125.0/24,102.68.188.0/22,102.69.152.0/22,102.176.176.0/22,102.178.0.0/15,102.180.0.0/16,102.209.188.0/23,102.211.121.0/24,102.212.160.0/23,102.214.40.0/22,102.214.64.0/22,102.216.120.0/22,102.219.0.0/22,102.219.92.0/24,102.222.56.0/22,102.222.120.0/22,102.223.174.0/23,105.235.176.0/20,129.45.128.0/17,154.65.60.0/22,154.66.160.0/20,160.226.184.0/22,165.16.208.0/20,192.12.116.0/24,192.136.55.0/24,192.136.56.0/24,192.136.57.0/24,196.13.207.0/24,196.28.240.0/20,196.43.247.0/24,196.49.19.0/24,196.49.74.0/24,196.60.76.0/24,196.223.47.0/24,197.239.64.0/18,212.52.128.0/19