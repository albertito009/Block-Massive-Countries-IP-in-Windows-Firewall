# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Suriname  `
dir=in action=block `
remoteip= `
`
45.68.20.0/23,45.68.22.0/24,138.186.208.0/22,168.121.84.0/22,168.195.216.0/22,186.179.128.0/17,190.98.0.0/19,190.98.32.0/19,190.98.64.0/18,200.1.156.0/22,200.1.208.0/21,200.2.160.0/20,200.2.176.0/20,200.7.148.0/22