# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_VirginIslands      `
dir=in action=block `
remoteip= `
`
23.143.120.0/24,66.59.216.0/24,66.248.160.0/19,67.211.240.0/20,98.142.160.0/20,132.147.224.0/20,136.143.195.0/24,146.226.0.0/16,172.84.192.0/18,192.65.170.0/24,192.81.72.0/23,192.102.82.0/24,198.36.28.0/22,204.8.64.0/22,204.11.152.0/21,208.84.192.0/21,209.221.192.0/19