# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Zambia      `
dir=in action=block `
remoteip= `
`
41.63.0.0/18,41.72.96.0/19,41.77.0.0/21,41.191.116.0/22,41.215.176.0/20,41.216.64.0/19,41.222.16.0/21,41.223.116.0/22,45.212.0.0/14,80.88.3.0/24,102.23.120.0/22,102.67.160.0/22,102.68.136.0/22,102.130.100.0/24,102.144.0.0/13,102.210.96.0/22,102.210.102.0/24,102.210.103.0/24,102.210.160.0/22,102.212.180.0/22,102.216.214.0/23,102.220.158.0/23,102.221.240.0/22,154.73.232.0/22,155.0.0.0/16,165.56.0.0/13,196.12.12.0/22,196.13.104.0/24,196.46.192.0/19,196.49.88.0/24,196.60.94.0/24,196.223.2.0/24,196.223.29.0/24,197.212.0.0/15,197.220.0.0/19,197.231.244.0/22