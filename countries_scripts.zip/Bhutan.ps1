# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Bhutan  `
dir=in action=block `
remoteip= `
`
36.50.37.0/24,43.229.124.0/22,43.230.208.0/24,43.241.136.0/22,45.64.248.0/22,103.7.252.0/22,103.29.224.0/22,103.71.40.0/22,103.78.111.0/24,103.78.116.0/23,103.80.108.0/22,103.97.87.0/24,103.117.80.0/24,103.119.126.0/24,103.127.254.0/24,103.129.62.0/23,103.133.216.0/22,103.151.231.0/24,103.161.248.0/23,103.166.42.0/23,103.179.206.0/23,103.197.176.0/22,103.234.126.0/23,103.245.240.0/22,103.252.84.0/24,118.103.136.0/21,119.2.96.0/19,157.10.120.0/23,157.10.122.0/23,157.10.124.0/23,157.10.126.0/23,157.10.128.0/23,157.10.136.0/23,157.10.138.0/23,157.10.140.0/23,157.10.142.0/23,157.10.144.0/23,157.10.146.0/23,202.89.24.0/21,202.144.128.0/19,220.158.236.0/22