# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Brunei  `
dir=in action=block `
remoteip= `
`
43.225.40.0/22,43.225.136.0/22,43.251.128.0/22,45.126.140.0/22,45.127.140.0/22,58.97.144.0/20,61.6.192.0/18,103.4.188.0/22,103.12.208.0/23,103.16.120.0/22,103.17.24.0/22,103.18.172.0/22,103.20.24.0/22,103.42.208.0/22,103.139.109.0/24,103.162.82.0/24,103.170.170.0/24,103.224.96.0/22,103.230.64.0/22,118.103.248.0/21,119.160.128.0/18,139.5.184.0/22,156.31.0.0/16,158.161.0.0/16,185.8.100.0/22,185.100.40.0/22,192.94.122.0/24,195.128.4.0/22,202.12.26.0/24,202.59.230.0/24,202.86.24.0/21,202.90.36.0/24,202.93.208.0/20,202.152.64.0/19,202.160.0.0/21,202.160.8.0/21,202.160.16.0/20,202.160.32.0/20