# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Maldives  `
dir=in action=block `
remoteip= `
`
27.114.128.0/18,36.255.104.0/23,43.226.220.0/22,43.231.28.0/22,43.247.140.0/22,69.94.32.0/20,69.94.80.0/20,83.137.200.0/21,103.15.52.0/22,103.19.224.0/22,103.31.84.0/22,103.50.104.0/22,103.55.161.0/24,103.67.26.0/24,103.71.57.0/24,103.76.2.0/24,103.84.132.0/24,103.84.134.0/24,103.87.188.0/24,103.103.66.0/24,103.110.40.0/24,103.110.109.0/24,103.110.110.0/23,103.119.75.0/24,103.141.98.0/24,103.143.252.0/24,103.172.31.0/24,103.173.79.0/24,103.182.172.0/24,103.191.77.0/24,103.197.164.0/22,103.248.112.0/22,115.84.128.0/19,123.176.0.0/19,124.195.192.0/19,150.107.196.0/22,185.215.32.0/22,202.1.192.0/22,202.1.196.0/22,202.1.200.0/21,202.21.176.0/20,202.153.80.0/21,203.82.2.0/23,203.104.24.0/21,209.212.192.0/19,216.183.208.0/20,220.158.220.0/22