# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Chad  `
dir=in action=block `
remoteip= `
`
41.242.152.0/21,102.23.84.0/22,102.131.56.0/22,102.164.244.0/22,102.211.107.0/24,102.212.248.0/22,102.218.112.0/22,102.220.101.0/24,102.220.196.0/22,102.223.48.0/22,102.223.192.0/22,154.68.128.0/19,154.73.112.0/22,154.73.160.0/21,169.239.120.0/22,169.255.152.0/22,196.49.92.0/24,196.60.106.0/24,196.223.42.0/24,197.149.128.0/22