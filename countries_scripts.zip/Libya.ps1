# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Libya  `
dir=in action=block `
remoteip= `
`
41.74.64.0/20,41.208.64.0/18,41.242.16.0/20,41.252.0.0/14,62.68.32.0/19,62.240.32.0/19,102.23.220.0/22,102.38.0.0/19,102.68.128.0/21,102.69.0.0/17,102.164.96.0/21,102.209.0.0/22,102.209.32.0/22,102.209.64.0/22,102.209.112.0/22,102.209.172.0/22,102.209.252.0/22,102.211.4.0/22,102.211.148.0/22,102.211.172.0/22,102.212.136.0/22,102.213.44.0/22,102.213.180.0/22,102.213.188.0/22,102.213.228.0/22,102.214.104.0/22,102.214.164.0/22,102.215.196.0/22,102.216.136.0/22,102.218.172.0/22,102.218.196.0/22,102.219.227.0/24,102.220.140.0/22,102.221.8.0/22,102.221.56.0/22,102.221.224.0/22,102.222.252.0/23,102.223.156.0/22,154.73.28.0/22,154.73.52.0/22,154.73.108.0/22,154.73.128.0/21,154.127.64.0/20,156.38.32.0/19,160.19.96.0/21,164.160.144.0/22,165.16.0.0/17,169.239.92.0/22,169.239.116.0/22,195.234.120.0/22,196.60.90.0/24,196.60.110.0/24,197.215.128.0/19,197.231.228.0/22,5.63.0.0/21,185.10.240.0/22