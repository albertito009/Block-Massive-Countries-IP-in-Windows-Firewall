# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Togo      `
dir=in action=block `
remoteip= `
`
41.78.136.0/22,41.207.160.0/19,80.248.64.0/20,102.64.128.0/17,102.164.224.0/20,102.176.252.0/22,102.212.92.0/22,102.217.12.0/22,102.219.236.0/22,154.70.80.0/20,156.38.64.0/19,160.242.192.0/18,196.49.44.0/24,196.60.42.0/24,196.168.0.0/14,197.148.96.0/19