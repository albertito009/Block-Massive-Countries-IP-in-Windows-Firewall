# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Vanuatu      `
dir=in action=block `
remoteip= `
`
103.7.197.0/24,103.16.15.0/24,103.20.232.0/23,103.25.228.0/23,103.36.144.0/22,103.65.141.0/24,103.72.90.0/23,103.75.20.0/23,103.100.10.0/24,103.101.192.0/24,103.125.232.0/22,103.226.22.0/23,113.11.240.0/21,180.222.208.0/22,202.4.251.0/24,202.61.106.0/23,202.80.32.0/20,203.191.128.0/22,194.127.164.0/22