# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Liberia  `
dir=in action=block `
remoteip= `
`
41.57.80.0/20,41.86.0.0/19,41.191.104.0/22,102.22.224.0/21,102.36.184.0/22,102.210.76.0/22,102.214.136.0/22,102.215.52.0/22,154.65.24.0/22,164.160.8.0/22,168.253.0.0/19,196.49.16.0/24,196.223.44.0/24,196.250.176.0/20,197.215.216.0/22,197.231.152.0/21,197.231.220.0/22,89.207.159.0/24