# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Malvinas  `
dir=in action=block `
remoteip= `
`
80.73.208.0/21,80.73.216.0/23,80.73.218.0/24,80.73.219.0/24,80.73.220.0/22,91.232.129.0/24,91.232.198.0/24,91.232.208.0/24,91.232.235.0/24,185.87.144.0/22,185.244.12.0/22