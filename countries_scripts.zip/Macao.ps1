# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Macao  `
dir=in action=block `
remoteip= `
`
27.109.128.0/17,43.247.24.0/22,45.64.20.0/22,45.123.200.0/22,60.246.0.0/16,103.5.218.0/23,103.88.176.0/22,103.96.60.0/22,103.115.140.0/22,103.143.92.0/23,103.192.44.0/22,103.233.188.0/22,103.237.100.0/22,103.237.124.0/22,103.240.56.0/23,113.52.64.0/18,116.193.8.0/21,122.100.128.0/18,122.100.192.0/19,122.100.224.0/19,123.253.200.0/22,125.31.0.0/18,161.64.0.0/16,163.53.244.0/22,180.94.128.0/18,182.93.0.0/18,192.203.232.0/24,202.75.248.0/22,202.86.128.0/18,202.174.0.0/22,202.175.0.0/22,202.175.4.0/22,202.175.8.0/21,202.175.16.0/20,202.175.32.0/19,202.175.64.0/19,202.175.96.0/19,202.175.160.0/19