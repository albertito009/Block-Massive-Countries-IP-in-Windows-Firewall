# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_TimorLeste      `
dir=in action=block `
remoteip= `
`
43.243.120.0/22,43.243.176.0/22,43.254.56.0/22,45.115.72.0/22,59.153.132.0/22,103.26.95.0/24,103.30.112.0/22,103.55.48.0/22,103.94.180.0/22,103.99.26.0/24,103.112.36.0/22,103.143.164.0/23,103.148.184.0/23,103.175.148.0/24,103.176.12.0/23,103.176.215.0/24,103.193.252.0/23,103.193.254.0/24,103.198.176.0/22,103.208.36.0/22,103.231.123.0/24,103.236.128.0/23,103.238.116.0/22,150.242.108.0/22,180.189.160.0/20,185.126.46.0/23,185.242.38.0/23