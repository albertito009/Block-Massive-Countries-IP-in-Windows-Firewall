# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Mali  `
dir=in action=block `
remoteip= `
`
41.73.96.0/19,41.203.192.0/20,41.221.176.0/20,102.68.176.0/22,102.130.232.0/22,102.165.96.0/20,102.212.72.0/22,102.213.136.0/22,102.217.24.0/22,102.221.132.0/22,102.222.204.0/22,102.223.64.0/22,154.70.192.0/22,154.118.128.0/18,165.90.208.0/20,169.239.100.0/22,196.10.216.0/21,196.32.112.0/20,196.49.48.0/24,196.50.16.0/22,196.60.46.0/24,196.200.48.0/20,196.200.80.0/20,196.251.156.0/22,197.155.128.0/18,217.64.96.0/20,217.170.144.0/20