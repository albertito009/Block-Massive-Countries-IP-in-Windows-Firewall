# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Qatar  `
dir=in action=block `
remoteip= `
`
5.180.36.0/22,31.11.48.0/21,37.186.32.0/19,37.208.128.0/17,37.210.0.0/15,78.100.0.0/15,80.76.160.0/20,81.29.160.0/20,82.148.96.0/19,86.36.0.0/18,86.36.64.0/19,86.36.96.0/19,86.36.128.0/17,86.37.0.0/16,86.62.192.0/18,89.211.0.0/16,91.228.176.0/24,92.42.103.0/24,94.125.224.0/21,103.14.208.0/22,103.17.0.0/22,103.23.124.0/22,103.199.88.0/22,103.225.72.0/22,176.202.0.0/15,178.23.16.0/21,178.152.0.0/15,185.2.244.0/22,185.25.12.0/22,185.37.96.0/22,185.37.108.0/22,185.96.224.0/22,185.104.56.0/22,185.107.76.0/22,185.154.168.0/22,185.239.92.0/22,185.247.88.0/22,212.70.96.0/19,212.77.192.0/19,213.130.96.0/19,213.178.136.0/22,185.1.159.0/24,194.6.255.0/24