# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_EquatorialGuinea  `
dir=in action=block `
remoteip= `
`
41.79.48.0/22,102.164.248.0/21,102.213.52.0/23,102.223.24.0/22,105.235.224.0/20,154.73.56.0/22,164.160.84.0/22,169.239.112.0/22,196.251.240.0/22,197.149.168.0/22,197.214.64.0/20