# Comprobar privilegios administrativos
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    # Relanzar el script con permisos elevados
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}


# Crear la regla de firewall para denegar peticiones entrantes
netsh advfirewall firewall add rule name=Deny_IP_Eswatini  `
dir=in action=block `
remoteip= `
`
41.77.232.0/21,41.84.224.0/19,41.204.0.0/19,41.211.32.0/19,41.215.144.0/20,69.63.64.0/20,102.23.132.0/22,102.36.181.0/24,102.67.144.0/22,102.68.48.0/22,102.209.176.0/22,102.212.200.0/22,102.212.228.0/24,102.214.160.0/22,102.215.24.0/22,102.215.99.0/24,102.222.132.0/22,154.119.96.0/19,165.73.132.0/22,196.11.124.0/24,196.13.168.0/24,196.28.7.0/24,196.49.4.0/24,196.223.37.0/24