netsh advfirewall firewall add rule name=Deny_IP_Anguilla1      `
dir=in action=block `
remoteip= `
104.192.92.0/22,104.193.196.0/22,104.255.176.0/22,162.251.108.0/22,162.254.188.0/22,192.30.124.0/24,204.14.248.0/21,208.66.48.0/21,195.149.107.0/24