netsh advfirewall firewall add rule name=Deny_IP_NorfolkIsland1      `
dir=in action=block `
remoteip= `
103.43.204.0/23,203.12.249.0/24,203.17.240.0/22,203.142.221.0/24