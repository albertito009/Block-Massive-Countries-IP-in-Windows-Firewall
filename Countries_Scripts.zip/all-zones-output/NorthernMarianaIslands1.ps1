netsh advfirewall firewall add rule name=Deny_IP_NorthernMarianaIslands1      `
dir=in action=block `
remoteip= `
45.117.196.0/22,103.1.96.0/22,103.57.232.0/22,202.88.64.0/20,202.88.80.0/20,210.23.80.0/20