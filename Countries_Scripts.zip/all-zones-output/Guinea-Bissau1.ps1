netsh advfirewall firewall add rule name=Deny_IP_Guinea-Bissau1      `
dir=in action=block `
remoteip= `
102.219.174.0/23,154.73.60.0/22,197.214.80.0/20