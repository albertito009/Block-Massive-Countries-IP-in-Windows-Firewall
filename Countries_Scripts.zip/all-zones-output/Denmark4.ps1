netsh advfirewall firewall add rule name=Deny_IP_Denmark4      `
dir=in action=block `
remoteip= `
195.246.198.0/24,195.254.168.0/23,213.5.32.0/21