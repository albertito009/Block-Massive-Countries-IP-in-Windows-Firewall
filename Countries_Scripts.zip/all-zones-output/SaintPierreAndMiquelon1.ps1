netsh advfirewall firewall add rule name=Deny_IP_SaintPierreAndMiquelon1      `
dir=in action=block `
remoteip= `
70.36.0.0/20,142.202.130.0/23