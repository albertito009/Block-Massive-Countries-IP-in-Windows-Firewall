netsh advfirewall firewall add rule name=Deny_IP_SaintBarthelemy1      `
dir=in action=block `
remoteip= `
23.135.232.0/24,149.112.20.0/24,206.83.45.0/24