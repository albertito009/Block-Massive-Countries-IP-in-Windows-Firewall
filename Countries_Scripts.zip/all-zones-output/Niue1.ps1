netsh advfirewall firewall add rule name=Deny_IP_Niue1      `
dir=in action=block `
remoteip= `
49.156.48.0/22,202.59.4.0/22