netsh advfirewall firewall add rule name=Deny_IP_Nauru1      `
dir=in action=block `
remoteip= `
43.230.6.0/24,103.20.124.0/24,103.36.150.0/23,103.49.173.0/24,103.49.174.0/23,203.98.224.0/19,203.190.216.0/24