netsh advfirewall firewall add rule name=Deny_IP_Mayotte1      `
dir=in action=block `
remoteip= `
41.242.116.0/22