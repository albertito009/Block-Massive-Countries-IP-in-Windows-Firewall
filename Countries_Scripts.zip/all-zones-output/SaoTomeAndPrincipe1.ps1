netsh advfirewall firewall add rule name=Deny_IP_SaoTomeAndPrincipe1      `
dir=in action=block `
remoteip= `
154.72.12.0/22,197.159.160.0/19