netsh advfirewall firewall add rule name=Deny_IP_FalklandIslandsMalvinas1      `
dir=in action=block `
remoteip= `
80.73.208.0/21,80.73.216.0/23,80.73.218.0/24,80.73.219.0/24,80.73.220.0/22,91.232.129.0/24,91.232.198.0/24,91.232.208.0/24,91.232.235.0/24,185.87.144.0/22,185.244.12.0/22