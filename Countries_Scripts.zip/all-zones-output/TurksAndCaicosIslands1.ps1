netsh advfirewall firewall add rule name=Deny_IP_TurksAndCaicosIslands1      `
dir=in action=block `
remoteip= `
65.255.48.0/20,142.54.204.0/22,192.203.37.0/24,199.103.28.0/22,199.182.192.0/22,204.13.104.0/22,204.110.56.0/21