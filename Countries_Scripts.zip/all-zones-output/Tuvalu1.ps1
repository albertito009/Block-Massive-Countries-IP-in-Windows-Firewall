netsh advfirewall firewall add rule name=Deny_IP_Tuvalu1      `
dir=in action=block `
remoteip= `
202.2.96.0/19