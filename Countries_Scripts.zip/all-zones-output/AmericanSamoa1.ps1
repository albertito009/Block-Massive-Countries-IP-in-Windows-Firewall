netsh advfirewall firewall add rule name=Deny_IP_AmericanSamoa1      `
dir=in action=block `
remoteip= `
103.117.168.0/22,103.238.156.0/23,202.70.112.0/20