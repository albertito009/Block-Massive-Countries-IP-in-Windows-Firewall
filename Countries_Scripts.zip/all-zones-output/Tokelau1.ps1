netsh advfirewall firewall add rule name=Deny_IP_Tokelau1      `
dir=in action=block `
remoteip= `
27.96.24.0/21,194.0.38.0/24,194.0.39.0/24,194.0.40.0/24,194.0.41.0/24