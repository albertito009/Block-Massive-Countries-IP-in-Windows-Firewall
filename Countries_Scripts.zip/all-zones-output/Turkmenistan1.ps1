netsh advfirewall firewall add rule name=Deny_IP_Turkmenistan1      `
dir=in action=block `
remoteip= `
95.85.96.0/19,103.220.0.0/22,119.235.112.0/20,177.93.143.0/24,185.69.184.0/22,185.246.72.0/22,216.250.8.0/21,217.174.224.0/20