netsh advfirewall firewall add rule name=Deny_IP_CookIslands1      `
dir=in action=block `
remoteip= `
116.199.200.0/23,202.65.32.0/19