netsh advfirewall firewall add rule name=Deny_IP_BonaireSintEustatiusAndSaba1      `
dir=in action=block `
remoteip= `
138.185.208.0/22,143.0.32.0/22,161.0.80.0/20,186.159.96.0/20,190.4.64.0/20,190.97.112.0/21,190.107.248.0/21,190.123.16.0/22,200.6.144.0/21,200.71.248.0/21,200.107.84.0/22,193.17.35.0/24