netsh advfirewall firewall add rule name=Deny_IP_Kiribati1      `
dir=in action=block `
remoteip= `
103.73.80.0/23,103.148.4.0/23,103.250.0.0/22,202.6.120.0/22,202.58.248.0/22