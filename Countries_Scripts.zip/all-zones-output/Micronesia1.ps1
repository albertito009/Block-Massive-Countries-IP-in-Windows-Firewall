netsh advfirewall firewall add rule name=Deny_IP_Micronesia1      `
dir=in action=block `
remoteip= `
43.248.156.0/22,103.39.252.0/22,103.166.208.0/23,119.252.112.0/20,124.109.8.0/21