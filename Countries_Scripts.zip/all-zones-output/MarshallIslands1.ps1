netsh advfirewall firewall add rule name=Deny_IP_MarshallIslands1      `
dir=in action=block `
remoteip= `
103.202.148.0/22,117.103.88.0/21,203.78.152.0/22,193.227.113.0/24