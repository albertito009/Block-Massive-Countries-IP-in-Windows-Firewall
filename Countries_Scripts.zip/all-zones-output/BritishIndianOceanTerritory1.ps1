netsh advfirewall firewall add rule name=Deny_IP_BritishIndianOceanTerritory1      `
dir=in action=block `
remoteip= `
202.44.112.0/22,203.83.48.0/21