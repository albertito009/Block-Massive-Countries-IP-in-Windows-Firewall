netsh advfirewall firewall add rule name=Deny_IP_Comoros1      `
dir=in action=block `
remoteip= `
102.223.120.0/22,164.160.136.0/22,197.255.224.0/20