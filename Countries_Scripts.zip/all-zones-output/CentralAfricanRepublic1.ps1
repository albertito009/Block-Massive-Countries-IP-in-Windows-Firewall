netsh advfirewall firewall add rule name=Deny_IP_CentralAfricanRepublic1      `
dir=in action=block `
remoteip= `
41.78.120.0/22,41.223.184.0/22,169.239.96.0/22,196.216.160.0/24,197.242.176.0/21