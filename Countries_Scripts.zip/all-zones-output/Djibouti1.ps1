netsh advfirewall firewall add rule name=Deny_IP_Djibouti1      `
dir=in action=block `
remoteip= `
41.189.224.0/19,102.214.90.0/24,196.49.10.0/24,196.201.192.0/20,196.223.38.0/24,197.241.0.0/17,91.209.83.0/24