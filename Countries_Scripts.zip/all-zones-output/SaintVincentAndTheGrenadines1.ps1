netsh advfirewall firewall add rule name=Deny_IP_SaintVincentAndTheGrenadines1      `
dir=in action=block `
remoteip= `
23.170.80.0/24,45.42.232.0/22,104.219.24.0/22,104.255.232.0/22,162.212.210.0/23,192.58.140.0/23,199.192.224.0/23,204.13.240.0/22,206.83.47.0/24,207.191.240.0/21,208.84.200.0/21