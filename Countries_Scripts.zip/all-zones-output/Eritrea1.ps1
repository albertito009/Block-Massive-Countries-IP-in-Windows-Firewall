netsh advfirewall firewall add rule name=Deny_IP_Eritrea1      `
dir=in action=block `
remoteip= `
196.200.96.0/20