# Ruta del directorio
$directory = "C:\Users\USER\Downloads\all-zones-output"

# Obtener la lista de archivos en el directorio
$files = Get-ChildItem $directory

# Recorrer cada archivo y ejecutarlo
foreach ($file in $files) {
    # Verificar si es un archivo
    if ($file.Attributes -notcontains 'Directory') {
        # Ejecutar el archivo
        Start-Process -FilePath $file.FullName -NoNewWindow
    }
}
