import os

def insert_block(directory):
    block_template = """netsh advfirewall firewall add rule name=Deny_IP_{filename}      `
dir=in action=block `
remoteip= `
"""
    for filename in os.listdir(directory):
        file_path = os.path.join(directory, filename)
        # Verifica si es un archivo
        if os.path.isfile(file_path):
            # Obtiene el nombre del archivo sin la extensión
            file_name_without_ext = os.path.splitext(filename)[0]
            # Lee el contenido original del archivo
            with open(file_path, 'r', encoding='utf-8') as original_file:
                original_content = original_file.read()
            # Genera el bloque de comandos con el nombre del archivo
            block = block_template.format(filename=file_name_without_ext)
            # Abre el archivo en modo de escritura
            with open(file_path, 'w', encoding='utf-8') as file:
                # Escribe el bloque de comandos al principio
                file.write(block)
                # Escribe el contenido original debajo del bloque de comandos
                file.write(original_content)

# Ejemplo de uso
directory = r'C:\Users\USER\Downloads\all-zones-output'
insert_block(directory)
