import os

def split_file(input_directory, output_directory, input_file_name, output_base_name, lines_per_file=350):
    input_file_path = os.path.join(input_directory, input_file_name)

    try:
        with open(input_file_path, 'r') as file:
            lines = file.readlines()

        total_lines = len(lines)
        num_files = (total_lines + lines_per_file - 1) // lines_per_file

        # Create the output directory if it doesn't exist
        if not os.path.exists(output_directory):
            os.makedirs(output_directory)

        for i in range(num_files):
            start_index = i * lines_per_file
            end_index = start_index + lines_per_file
            chunk = lines[start_index:end_index]

            output_file_name = f"{output_base_name}{i+1}.ps1"
            output_file_path = os.path.join(output_directory, output_file_name)
            
            with open(output_file_path, 'w') as output:
                output.writelines(chunk)
            
            print(f"Created {output_file_path} with {len(chunk)} lines.")

    except FileNotFoundError:
        print(f"Error: The file {input_file_path} does not exist.")
    except Exception as e:
        print(f"An error occurred: {e}")

def process_directory(input_directory, output_directory, lines_per_file=350):
    try:
        for file_name in os.listdir(input_directory):
            if file_name.endswith('.ps1'):
                # Remove the extension for the base name
                base_name = os.path.splitext(file_name)[0]
                split_file(input_directory, output_directory, file_name, base_name, lines_per_file)
    except FileNotFoundError:
        print(f"Error: The directory {input_directory} does not exist.")
    except Exception as e:
        print(f"An error occurred: {e}")

# Especifica los directorios que contienen los archivos y donde se guardaran los nuevos archivos
input_directory = r'C:\Users\USER\Downloads\all-zones'  # Cambia esto por el directorio adecuado
output_directory = r'C:\Users\USER\Downloads\all-zones-output'  # Cambia esto por el directorio de salida DEBE EXISTIR / MUST BE EXIST

# Llamada a la funcion para procesar el directorio
process_directory(input_directory, output_directory)
