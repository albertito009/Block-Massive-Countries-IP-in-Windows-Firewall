
# Hash table para mapear codigos de pais a nombres de pais

# https://www.ipdeny.com/ipblocks/

$countryCodes = @{
    "AF" = "Afghanistan"; "AX" = "AlandIslands"; "AL" = "Albania"; "DZ" = "Algeria";
    "AS" = "AmericanSamoa"; "AD" = "Andorra"; "AO" = "Angola"; "AI" = "Anguilla";
    "AQ" = "Antarctica"; "AG" = "AntiguaAndBarbuda"; "AR" = "Argentina"; "AM" = "Armenia";
    "AW" = "Aruba"; "AU" = "Australia"; "AT" = "Austria"; "AZ" = "Azerbaijan";
    "BS" = "Bahamas"; "BH" = "Bahrain"; "BD" = "Bangladesh"; "BB" = "Barbados";
    "BY" = "Belarus"; "BE" = "Belgium"; "BZ" = "Belize"; "BJ" = "Benin";
    "BM" = "Bermuda"; "BT" = "Bhutan"; "BO" = "Bolivia"; "BQ" = "BonaireSintEustatiusAndSaba";
    "BA" = "BosniaAndHerzegovina"; "BW" = "Botswana"; "BV" = "BouvetIsland"; "BR" = "Brazil";
    "IO" = "BritishIndianOceanTerritory"; "BN" = "BruneiDarussalam"; "BG" = "Bulgaria"; "BF" = "BurkinaFaso";
    "BI" = "Burundi"; "CV" = "CaboVerde"; "KH" = "Cambodia"; "CM" = "Cameroon";
    "CA" = "Canada"; "KY" = "CaymanIslands"; "CF" = "CentralAfricanRepublic"; "TD" = "Chad";
    "CL" = "Chile"; "CN" = "China"; "CX" = "ChristmasIsland"; "CC" = "CocosKeelingIslands";
    "CO" = "Colombia"; "KM" = "Comoros"; "CG" = "Congo"; "CD" = "CongoDemocraticRepublicOfThe";
    "CK" = "CookIslands"; "CR" = "CostaRica"; "HR" = "Croatia"; "CU" = "Cuba";
    "CW" = "Curacao"; "CY" = "Cyprus"; "CZ" = "Czechia"; "DK" = "Denmark";
    "DJ" = "Djibouti"; "DM" = "Dominica"; "DO" = "DominicanRepublic"; "EC" = "Ecuador";
    "EG" = "Egypt"; "SV" = "ElSalvador"; "GQ" = "EquatorialGuinea"; "ER" = "Eritrea";
    "EE" = "Estonia"; "SZ" = "Eswatini"; "ET" = "Ethiopia"; "FK" = "FalklandIslandsMalvinas";
    "FO" = "FaroeIslands"; "FJ" = "Fiji"; "FI" = "Finland"; "FR" = "France";
    "GF" = "FrenchGuiana"; "PF" = "FrenchPolynesia"; "TF" = "FrenchSouthernTerritories"; "GA" = "Gabon";
    "GM" = "Gambia"; "GE" = "Georgia"; "DE" = "Germany"; "GH" = "Ghana";
    "GI" = "Gibraltar"; "GR" = "Greece"; "GL" = "Greenland"; "GD" = "Grenada";
    "GP" = "Guadeloupe"; "GU" = "Guam"; "GT" = "Guatemala"; "GG" = "Guernsey";
    "GN" = "Guinea"; "GW" = "Guinea-Bissau"; "GY" = "Guyana"; "HT" = "Haiti";
    "HM" = "HeardIslandAndMcDonaldIslands"; "VA" = "HolySee"; "HN" = "Honduras"; "HK" = "HongKong";
    "HU" = "Hungary"; "IS" = "Iceland"; "IN" = "India"; "ID" = "Indonesia";
    "IR" = "Iran"; "IQ" = "Iraq"; "IE" = "Ireland"; "IM" = "IsleOfMan";
    "IL" = "Israel"; "IT" = "Italy"; "JM" = "Jamaica"; "JP" = "Japan";
    "JE" = "Jersey"; "JO" = "Jordan"; "KZ" = "Kazakhstan"; "KE" = "Kenya";
    "KI" = "Kiribati"; "KP" = "NorthKorea"; "KR" = "SouthKorea"; "KW" = "Kuwait";
    "KG" = "Kyrgyzstan"; "LA" = "Laos"; "LV" = "Latvia"; "LB" = "Lebanon";
    "LS" = "Lesotho"; "LR" = "Liberia"; "LY" = "Libya"; "LI" = "Liechtenstein";
    "LT" = "Lithuania"; "LU" = "Luxembourg"; "MO" = "Macao"; "MG" = "Madagascar";
    "MW" = "Malawi"; "MY" = "Malaysia"; "MV" = "Maldives"; "ML" = "Mali";
    "MT" = "Malta"; "MH" = "MarshallIslands"; "MQ" = "Martinique"; "MR" = "Mauritania";
    "MU" = "Mauritius"; "YT" = "Mayotte"; "MX" = "Mexico"; "FM" = "Micronesia";
    "MD" = "Moldova"; "MC" = "Monaco"; "MN" = "Mongolia"; "ME" = "Montenegro";
    "MS" = "Montserrat"; "MA" = "Morocco"; "MZ" = "Mozambique"; "MM" = "Myanmar";
    "NA" = "Namibia"; "NR" = "Nauru"; "NP" = "Nepal"; "NL" = "Netherlands";
    "NC" = "NewCaledonia"; "NZ" = "NewZealand"; "NI" = "Nicaragua"; "NE" = "Niger";
    "NG" = "Nigeria"; "NU" = "Niue"; "NF" = "NorfolkIsland"; "MK" = "NorthMacedonia";
    "MP" = "NorthernMarianaIslands"; "NO" = "Norway"; "OM" = "Oman"; "PK" = "Pakistan";
    "PW" = "Palau"; "PS" = "Palestine"; "PA" = "Panama"; "PG" = "PapuaNewGuinea";
    "PY" = "Paraguay"; "PE" = "Peru"; "PH" = "Philippines"; "PN" = "Pitcairn";
    "PL" = "Poland"; "PT" = "Portugal"; "PR" = "PuertoRico"; "QA" = "Qatar";
    "RE" = "Reunion"; "RO" = "Romania"; "RU" = "Russia"; "RW" = "Rwanda";
    "BL" = "SaintBarthelemy"; "SH" = "SaintHelena"; "KN" = "SaintKittsAndNevis"; "LC" = "SaintLucia";
    "MF" = "SaintMartin"; "PM" = "SaintPierreAndMiquelon"; "VC" = "SaintVincentAndTheGrenadines"; "WS" = "Samoa";
    "SM" = "SanMarino"; "ST" = "SaoTomeAndPrincipe"; "SA" = "SaudiArabia"; "SN" = "Senegal";
    "RS" = "Serbia"; "SC" = "Seychelles"; "SL" = "SierraLeone"; "SG" = "Singapore";
    "SX" = "SintMaarten"; "SK" = "Slovakia"; "SI" = "Slovenia"; "SB" = "SolomonIslands";
    "SO" = "Somalia"; "ZA" = "SouthAfrica"; "GS" = "SouthGeorgiaAndTheSouthSandwichIslands"; "SS" = "SouthSudan";
    "ES" = "Spain"; "LK" = "SriLanka"; "SD" = "Sudan"; "SR" = "Suriname";
    "SJ" = "SvalbardAndJanMayen"; "SE" = "Sweden"; "CH" = "Switzerland"; "SY" = "Syria";
    "TW" = "Taiwan"; "TJ" = "Tajikistan"; "TZ" = "Tanzania"; "TH" = "Thailand";
    "TL" = "TimorLeste"; "TG" = "Togo"; "TK" = "Tokelau"; "TO" = "Tonga";
    "TT" = "TrinidadAndTobago"; "TN" = "Tunisia"; "TR" = "Turkey"; "TM" = "Turkmenistan";
    "TC" = "TurksAndCaicosIslands"; "TV" = "Tuvalu"; "UG" = "Uganda"; "UA" = "Ukraine";
    "AE" = "UnitedArabEmirates"; "GB" = "UnitedKingdom"; "US" = "UnitedStates"; "UM" = "UnitedStatesMinorOutlyingIslands";
    "UY" = "Uruguay"; "UZ" = "Uzbekistan"; "VU" = "Vanuatu"; "VE" = "Venezuela";
    "VN" = "Vietnam"; "VG" = "VirginIslandsBritish"; "VI" = "VirginIslandsUS"; "WF" = "WallisAndFutuna";
    "EH" = "WesternSahara"; "YE" = "Yemen"; "ZM" = "Zambia"; "ZW" = "Zimbabwe";
}

# Directorio donde estan los archivos
$directory = "C:\Users\USER\Downloads\all-zones"

# Obtener todos los archivos .zone en el directorio
$files = Get-ChildItem -Path $directory -Filter *.zone

foreach ($file in $files) {
    # Obtener el codigo del pais del nombre del archivo
    $countryCode = $file.BaseName

    # Verificar si el codigo del pais esta en la hash table
    if ($countryCodes.ContainsKey($countryCode)) {
        # Obtener el nombre del pais de la hash table
        $countryName = $countryCodes[$countryCode]

        # Crear el nuevo nombre de archivo con la extension .ps1
        $newFileName = "$countryName.ps1"

        # Obtener la ruta completa del nuevo archivo
        $newFilePath = Join-Path -Path $directory -ChildPath $newFileName

        # Renombrar el archivo
        Rename-Item -Path $file.FullName -NewName $newFilePath
        Write-Output "Renombrado: $($file.FullName) a $newFilePath"
    } else {
        Write-Output "Codigo de pais no encontrado: $countryCode"
    }
}
