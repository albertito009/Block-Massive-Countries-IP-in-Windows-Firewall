import os

def replace_newline_with_comma(directory):
    for filename in os.listdir(directory):
        file_path = os.path.join(directory, filename)
        # Verifica si es un archivo
        if os.path.isfile(file_path):
            # Lee todo el contenido del archivo
            with open(file_path, 'r', encoding='utf-8') as file:
                content = file.read()
            # Reemplaza los saltos de línea por comas
            content = content.replace('\n', ',')
            # Escribe el contenido modificado de vuelta al archivo
            with open(file_path, 'w', encoding='utf-8') as file:
                file.write(content)

# Directorio que contiene los archivos
directory = r'C:\Users\USER\Downloads\all-zones-output'
replace_newline_with_comma(directory)
