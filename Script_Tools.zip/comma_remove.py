import os

def remove_last_comma(directory):
    for filename in os.listdir(directory):
        file_path = os.path.join(directory, filename)
        # Verifica si es un archivo
        if os.path.isfile(file_path):
            with open(file_path, 'r+', encoding='utf-8') as file:
                file.seek(0, os.SEEK_END)  # Mueve el cursor al final del archivo
                file.seek(file.tell() - 1, os.SEEK_SET)  # Retrocede un carácter
                last_char = file.read(1)
                if last_char == ',':
                    file.seek(file.tell() - 1, os.SEEK_SET)  # Retrocede un carácter de nuevo
                    file.truncate()  # Trunca el archivo en la posición actual

# Ejemplo de uso
directory = r'C:\Users\USER\Downloads\all-zones-output'
remove_last_comma(directory)
